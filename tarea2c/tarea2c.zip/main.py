from view.view import start
__author__ = "Camilo Núñez Barra"
if __name__ == "__main__": start()